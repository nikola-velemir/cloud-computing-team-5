import base64
import uuid
import boto3
from requests_toolbelt.multipart.decoder import MultipartDecoder

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('SongifyDynamo')
BUCKET_NAME = 'songs-bucket-cc5-2025'

def lambda_handler(event,context):
    headers = event.get('headers') or {}
    content_type = headers.get('content-type') or headers.get('Content-Type')
    if not content_type:
        return {
            "statusCode": 400,
            "body": json.dumps({"message": "Missing Content-Type header"})
        }
    
    body_bytes = _decode_body(event=event)

    multipart_data = MultipartDecoder(body_bytes, content_type)

    parsed_body = _parse_body(multipart_data)
    song_id = str(uuid.uuid4())
    image_key = f'songs/{song_id}/cover/cover.jpg'
    audio_key = f'songs/{song_id}/audio/audio.mp3'

    if _parse_body['image_data']:
        s3.put_object(
            Bucket = BUCKET_NAME,
            Key = image_key,
            Body = _parse_body['image_data'],
            ContentType=_parse_body['image_content_type']
        )
    if _parse_body['audio_data']:
        s3.put_object(
            Bucket = BUCKET_NAME,
            Key = audio_key,
            Body = _parse_body['audio_data'],
            ContentType=_parse_body['audio_content_type']
        )
    
    table.put_item(
        Item = {
            'PK' : f"SONG#{song_id}",
            "SK" : f'METADATA',
            "Name" : _parse_body['song_name'],
            "ImageUrl" : f'https/{BUCKET_NAME}.s3.amazonaws.com/{image_key}',
            "AudioUrl" :  f'https/{BUCKET_NAME}.s3.amazonaws.com/{audio_key}'
        }
    )
    return {
        "statusCode": 201,
        "body": json.dumps({
            "songId": song_id,
            "songName": parsed_body["song_name"],
            "genreId": parsed_body["genre_id"]
        })
    }


def _parse_body(multipart_data):
    song_name = ''
    genre_id = ''
    image_data = None
    image_content_type = None
    audio_data =None
    audio_content_type = None

    for part in multipart_data.parts:
        cd = part.headers[b'Content-Disposition'].decode()
        if 'name=songName' in cd:
            song_name = part.text
        elif 'name=genreId' in cd:
            genre_id = part.text
        elif 'name=image' in cd:
            image_data = part.content
            image_content_type = part.headers.get(b'Content-Type', b'image/jpeg').decode()
        elif 'name=audio' in cd:
            audio_data = part.content
            audio_content_type = part.headers.get(b'Content-Type', b'audio/mpeg').decode()
    
    return {
        'song_name':song_name,
        'genre_id':genre_id,
        'image_data':image_data,
        'image_content_type':image_content_type,
        'audio_data' : audio_data,
        'audio_content_type' : audio_content_type
    }



def _decode_body(event):
    if event.get('isBase64Encoded',False):
        body_bytes = base64.b64decode(event['body'])
    else:
        body_bytes = event['body'].encode("utf-8")
    return body_bytes